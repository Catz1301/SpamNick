package gq.catz.spamnick;

import android.content.ContentProvider;
import android.graphics.Color;
//import android.support.constraint.ConstraintLayout;
import android.os.Bundle;
import android.telephony.*;
import android.telephony.SmsMessage;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

//import
public class MainActivity extends AppCompatActivity {
	public boolean threadsRunning = false;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		EditText msg = (EditText) findViewById(R.id.editTextSpamMsg), waitTime = (EditText) findViewById(R.id.editTextWaitTime);
		Button start = (Button) findViewById(R.id.startSpam), stop = (Button) findViewById(R.id.stopSpam);
		ConstraintLayout layout = (ConstraintLayout) findViewById(R.id.layout_main);

		start.setOnClickListener(v -> {
			threadsRunning = true;
			layout.setBackgroundColor(Color.GREEN);
			String msgString = msg.getText().toString();
			String waitTimeMs = waitTime.getText().toString();
			StartTheSpam(msgString, Integer.valueOf(waitTimeMs));
		});

		stop.setOnClickListener(v -> {
			layout.setBackgroundColor(Color.RED);
			threadsRunning = false;
		});
	}

	private void StartTheSpam(String msgString, int waitTimeMs) {
		final String msgStr = msgString;
		final int waitTimeMilli = waitTimeMs;

		Thread t = new Thread(new Runnable() {
			@Override
			public void run() {
				while (threadsRunning == true) {
					sendSMS("5176671277", msgStr);
					try {
						Thread.sleep(waitTimeMilli);
					} catch (InterruptedException e) {
						Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
						e.printStackTrace();
					}
				}
			}
			void sendSMS(String phoneNum, String msg) {
				try {
					SmsManager smsManager = SmsManager.getDefault();
					smsManager.sendTextMessage(phoneNum, null, msg, null, null);
//					putInSmsDb(msg, phoneNum);
				} catch (Exception ex) {
					Toast.makeText(getApplicationContext(), ex.getMessage(), Toast.LENGTH_LONG).show();
					ex.printStackTrace();
				}
			}
		});
		t.start();
	}
}
package gq.catz.spamnick;

import android.annotation.TargetApi;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.widget.Toast;

import java.security.Provider;

public class SmsReceiver extends BroadcastReceiver {
	private static final String TAG = SmsReceiver.class.getSimpleName();
	private static final String pdu_type = "pdus";
	@TargetApi(Build.VERSION_CODES.M)
	@Override
	public void onReceive(Context context, Intent intent) {
		Toast.makeText(context, "Sms Recieved", Toast.LENGTH_LONG).show();
		Bundle bundle = intent.getExtras();
		SmsMessage[] msgs;
		String strMsg = "";
		String finalStrMsg = "";
		String originatingAddress = "";
		String format = bundle.getString("format");
		Object[] pdus = (Object[]) bundle.get(pdu_type);
		boolean isVersionM = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M);
		msgs = new SmsMessage[pdus.length];
		for (int i = 0; i < msgs.length; i++) {
			//originatingAddress = msgs[i].getOriginatingAddress();
			if (isVersionM) {
				msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i], format);
			} else {
				msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
			}
			strMsg += msgs[i].getMessageBody();
		}
		finalStrMsg += "SMS from " + "5172133733";
		finalStrMsg += " : " + strMsg;
		Toast.makeText(context, finalStrMsg, Toast.LENGTH_LONG).show();
	}
}
